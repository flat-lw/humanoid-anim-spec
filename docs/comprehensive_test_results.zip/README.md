# Comprehensive Animation Test Results

## Test Date: 2026-01-05

## Test 1: YAML to .anim Generation

Generated animation files from YAML configurations:

| Input File | Output File | Size |
|------------|-------------|------|
| examples/wave_hand.yaml | wave_hand.anim | 832KB |
| examples/reach_forward.yaml | reach_forward.anim | 631KB |

**Result: SUCCESS**

## Test 2: .anim Round-trip (No IK)

Tested muscle value preservation through FK->IK round-trip:

- Input: /tmp/squat.anim
- Output: squat_roundtrip.anim

### Key Results:
- Upper Leg Front-Back: 0.842343 -> 0.842343 (EXACT MATCH)
- Upper Leg In-Out: 0.023480 -> 0.023480 (EXACT MATCH)
- Lower Leg Stretch: 0.928497 -> 0.928497 (EXACT MATCH)
- Spine/Chest/Head muscles: All exact matches

### Known Differences:
- Forearm Stretch: Input -0.241379 -> Output 0.0 (Not yet supported in musclesToTransforms)
- RootT values: Different calculation method
- Upper Leg Twist: Small numeric error (0.0 -> 0.009041)

**Result: MOSTLY SUCCESS (Core muscles match exactly)**

## Test 3: .anim with IK Constraints

### 3a. Fixed Feet (LeftFoot, RightFoot fixed)
- Output: squat_fixed_feet.anim
- IK converged on all frames

### 3b. Hand Effectors (LeftHand, RightHand as effectors)
- Output: squat_hand_effectors.anim
- IK converged on all frames

**Result: SUCCESS**

## Files in this Archive

| File | Description |
|------|-------------|
| wave_hand.anim | Generated from wave_hand.yaml |
| reach_forward.anim | Generated from reach_forward.yaml |
| squat_roundtrip.anim | Round-trip test (no IK) |
| squat_fixed_feet.anim | IK with fixed feet |
| squat_hand_effectors.anim | IK with hand effectors |
| README.md | This file |
